package devandroid.nicolas.applistacurso.controller;

public class CursoController {
}
